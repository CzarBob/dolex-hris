// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable();
});

$(document).ready(function () {
  $('#adminapproved').DataTable();
});

$(document).ready(function () {
  $('#applicant').DataTable();
});
$(document).ready(function () {
  $('#approved').DataTable();
});